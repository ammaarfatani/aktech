"use client";

import { motion } from "framer-motion";
import { usePathname } from "next/navigation";
import { siteConfig } from "@/config/site";
import services from "@/data/seo-services.json";

export function WhatsAppButton() {
  const pathname = usePathname();
  const service = services.find(page => page.path === pathname);
  const defaultMessage = encodeURIComponent(`Hi AKTECH, I would like to discuss ${service?.title || "a project"}. Page: ${siteConfig.url}${pathname}`);
  const whatsappUrl = `${siteConfig.links.whatsapp}?text=${defaultMessage}`;

  return (
    <motion.a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp with AKTECH"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.5, delay: 1, ease: [0.16, 1, 0.3, 1] }}
      className="fixed bottom-6 right-6 z-[9999] group flex items-center gap-3 p-3.5 sm:px-5 sm:py-3.5 rounded-full bg-[#25D366] text-white shadow-xl shadow-[#25D366]/30 hover:shadow-2xl hover:shadow-[#25D366]/50 hover:scale-105 active:scale-95 transition-all duration-300 ease-out cursor-pointer"
    >
      {/* Subtle pulse ring */}
      <span className="absolute inset-0 rounded-full bg-[#25D366]/40 animate-[chatPulseRing_2s_ease-out_infinite] pointer-events-none" />

      {/* WhatsApp SVG Icon */}
      <svg
        className="w-6 h-6 fill-current relative z-10"
        viewBox="0 0 24 24"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.096 3.2 5.077 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.99c-.002 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
      </svg>

      <span className="hidden sm:inline font-bold text-xs tracking-wider uppercase relative z-10">
        WhatsApp Us
      </span>
    </motion.a>
  );
}
